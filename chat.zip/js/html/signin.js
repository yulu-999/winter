//  设置背景background
function setBackground(){
    let $winWidth = $(window).width();
    let $winHeight = $(window).height();
    let $background = $("#background");
    $background.css({"width":$winWidth,"height":$winHeight})
}
setBackground()
$(window).resize( function  () {           //当浏览器大小变化时
    setBackground()
});


//用户注册
// 发送验证码
code();
//用户注册
register();


//注册用户
function register(){
    //获取注册对象
    let $register = $("#register");
    //监听点击事件
    $register.click(function (){
        //获取值
        let name = $("#name").val();
        let email = $("#email").val();
        let password = $("#password").val();
        let confirm = $("#confirm").val();
        let code = $("#code").val();
        if (password==confirm){
            registerUser(name,email,password,code)
        }else {
            alert("两次密码不一样")
        }
    });

}



//注册
function registerUser(userName,email,password,code) {
    console.log("请求的url"+url+"sign/register")
    $.ajax({
        //请求方式
        type : "POST",
        //请求的媒体类型
        // contentType: "application/json;charset=utf8",
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'  //multipart/form-data;boundary=--xxxxxxx   application/json
        },
        //请求地址
        url : url+"sign/register",
        //数据，json字符串
        data : {
            'email':email,
            'username':userName,
            'password':password,
            'code':code
        },
        //请求成功
        success : function(data) {
            if (data.code=="200"||data.code=='-4'){
                alert(data.msg)
                window.location.href='login.html';
            }
            else {
                alert(data.msg)
            }
        },
        //请求失败，包含具体的错误信息
        error : function(e){
            alert("发送失败")
        }
    });
}

//发送验证码
function code(){
    //监听发送按钮 发送事件
    $("#getCode").click(
        function (){
            //获取值
            let email = $("#email").val();

            setCode(email);
        }
    );
}

//发送请求的ajax
function setCode(email) {
    $.ajax({
        //请求方式
        type : "GET",
        //请求的媒体类型
        contentType: "application/json;charset=UTF-8",
        //请求地址
        url : url+"sign/sendcode",
        //数据，json字符串
        data : {
            'email':email
        },
        //请求成功
        success : function(data) {
            if (data.code=="200"){
                alert(data.msg)
            }else {
                alert(data.msg)
            }
        },
        //请求失败，包含具体的错误信息
        error : function(e){
            alert("发送失败")
        }
    });
}
