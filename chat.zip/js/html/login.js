//  设置背景background
function setBackground(){
    let $winWidth = $(window).width();
    let $winHeight = $(window).height();
    let $background = $("#background");
    $background.css({"width":$winWidth,"height":$winHeight})
}
setBackground()
$(window).resize( function  () {           //当浏览器大小变化时
    setBackground()
});

//登录
login();

function login() {
    //登录对象
    let $login = $("#login");
    $login.click(function (){
        let username = $("#username").val();
        let Password = $("#Password").val();
        console.log(username)
        console.log(Password)
        codePassword(username,Password);
    });
}


//发送
function codePassword(userName,PassWord) {
    console.log("请求的url"+url+"login")
    $.ajax({
        //请求方式
        type : "POST",
        //请求的媒体类型
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'  //multipart/form-data;boundary=--xxxxxxx   application/json
        },
        //请求地址
        url : url+"sign/sign",
        //数据，json字符串
        data : {
            'username':userName,
            'password':PassWord,
        },
        //请求成功
        success : function(data) {
            if (data.code=="200"){
              let token = data.data.token;
              localStorage.setItem('token',token)
              alert("登录成功");
              window.location.href='chat.html';
            }
            else {
                alert(data.msg)
            }
        },
        //请求失败，包含具体的错误信息
        error : function(e){
            alert("发送失败")
        }
    });
}