/*
 ------- user 的 li -----------
 <li class="person" data-chat="1">
                    <img src="img/1.jpg" alt="">
                    <span class="name">大力水手</span>
                    <span class="time">2:09 PM</span>
                    <span class="preview">我想知道...</span>
 </li>
-----------------------------------


---------------  聊天内容 的 demo  -------------------
          <div class="chat" data-chat="person5">
                <div class="conversation-start">
                    <span>今天, 6:28 AM</span>
                </div>
                <div class="bubble you">
                    醒醒
                </div>
                <div class="bubble you">
                    醒醒
                </div>
                <div class="bubble you">
                    我需要三件东西：爱情友谊和图书。然而这三者之间何其相通！炽热的爱情可以充实图书的内容，图书又是人们最忠实的朋友
                </div>
            </div>
-----------------------------------
 */
//取出token
let  token = localStorage.getItem("token");
console.log(token);
getUser();

let id = "";


/**
 * 增加用户
 * @param obj 增加的对象
 * @param typeName data-chat 属性的名
 * @param headPath 头像的路径
 * @param userName 用户名
 * @param time  最后一条聊天记录的时间
 * @param preview 最后一条聊天记录的内容
 */
function addUser(obj,typeName,headPath,userName,time,preview) {

    let data = " <li class=\"person\" data-chat="+typeName+">\n" +
        "                    <img src="+headPath+" alt=\"\">\n" +
        "                    <span class=\"name\">"+userName+"</span>\n" +
        "                    <span class=\"time\">"+time+"</span>\n" +
        "                    <span class=\"preview\">"+preview+"</span>\n" +
        " </li>"

    obj.append(data);
}


/**
 * 增加聊天内容
 * @param obj 增加的对象
 * @param className 区分你我的消息
 * @param preview  聊天内容
 */
function addChatConME(obj,preview){
    let data = "<div class='bubble me'>\n"+ preview+"</div>";
    obj.append(data);
}

function addChatConYou(obj,preview){
    let data = "<div class='bubble you'>\n"+ preview+"</div>";
    obj.append(data);
}

function  chatVessel(obj,dataChat) {
    let data = "<div class='chat' data-chat="+dataChat+">" +
        "                    <div class=\"conversation-start\">\n" +
        "                        <span>今天, 6:48 AM</span>\n" +
        "                    </div>" +
        "</div>"
    obj.append(data)
}



//第一次获取使用 ajax 请求
/**
 * 获取用户 -----注意我们是没有好友的 所以获取的用户是全部的用户
 */
function  getUser() {
    $.ajax({
        //请求方式
        type : "GET",
        //请求头
        headers:{
            'Content-Type':'application/json;charset=utf8'
        },
        dataType:"json",
        //请求地址
        url : url+"chat/home",
        //数据，json字符串
        data : {
            'token':token
        },
        //请求成功
        success : function(data) {
            console.log(data)

            if (data.code==200){
                id = data.data.id;
                console.log(id)
                let userlist = data.data.userlist;

                for (let i = 0; i < userlist.length; i++) {
                    var $people = $(".people");
                    addUser($people,userlist[i].userid,userlist[i].head,userlist[i].username,"12:00 PM" ,userlist[i].content)
                    //创建聊天的容器
                    var right = $(".right");
                    chatVessel(right,userlist[i].userid)
                    var chatmsg = userlist[i].chatmsg;
                    var chatThis = $(".chat[data-chat="+userlist[i].userid+"]");
                    for (let j = 0; j < chatmsg.length; j++) {
                        if (chatmsg[j].inituser==id){
                            addChatConME(chatThis,chatmsg[j].content);
                        }
                        else {
                            addChatConYou(chatThis,chatmsg[j].content);
                        }
                    }
                }







                //增加信息
                var friends = {
                        list: document.querySelector('ul.people'),
                        all: document.querySelectorAll('.left .person'),
                        name: '' },

                    chat = {
                        container: document.querySelector('.container .right'),
                        current: null,
                        person: null,
                        name: document.querySelector('.container .right .top .name') };


                friends.all.forEach(function (f) {
                    f.addEventListener('mousedown', function () {
                        f.classList.contains('active') || setAciveChat(f);
                    });
                });



                function setAciveChat(f) {
                    friends.list.querySelector('.active').classList.remove('active');
                    f.classList.add('active');
                    chat.current = chat.container.querySelector('.active-chat');
                    chat.person = f.getAttribute('data-chat');
                    chat.current.classList.remove('active-chat');
                    chat.container.querySelector('[data-chat="' + chat.person + '"]').classList.add('active-chat');
                    friends.name = f.querySelector('.name').innerText;
                    chat.name.innerHTML = friends.name;
                }

                addWiter()

            }else if (data.code==-1) {
                 alert("请重新登陆")
                window.location.href='login.html';
            }

        },
        //请求失败，包含具体的错误信息
        error : function(e){

        }
    });


}




function addWiter() {
    let data = "            <div class=\"write\">\n" +
        "                <a href=\"javascript:;\" class=\"write-link attach\"></a>\n" +
        "                <input type=\"text\" id=\"chatmsg\">\n" +
        "                <a href=\"javascript:;\" class=\"write-link smiley\"></a>\n" +
        "                <a href=\"javascript:;\" id='send' class=\"write-link send\"></a>\n" +
        "            </div>"
    $(".right").append(data)
}




function removemWiter() {
    $(".write").remove()
}

console.log($(".top .name").html())

// var chatThis = $(".chat[data-chat="+id+"]");
var  wsurl = "ws://localhost:8080/chat/chat/chat/"+token;

var webSocket=new WebSocket(wsurl);

//建立连接
webSocket.onopen = function(evt) {
    console.log("建立连接");
    //send 向服务端发送数据
    // webSocket.send("Hello WebSockets!");
    //绑定事件
};



$(document).keyup(function(event){
    if(event.keyCode ==13){
        //这里填写你要做的事件
        //TODO
        webSocket.send(sendChat())
        var content = $("#chatmsg").val("");
        console.log(id)
    }
});


//接收消息 onmessage
webSocket.onmessage=function(event){

    var data  = JSON.parse(event.data);
    console.log("接收到的消息"+event.data)
    console.log(data.inituser)
    let userid = "";
    if (data.inituser==id){
        userid = data.reception;
    }else {
        userid=id;
    }
    var chatThis = $(".chat[data-chat="+userid+"]");
    if (data.inituser==id){
        console.log("我的消息")
        addChatConME(chatThis,data.content);
    }
    else {
        console.log("你的消息")
        addChatConYou(chatThis,data.content);
    }



}

function sendChat() {
    var userName = $(".top .name").html();
    var content = $("#chatmsg").val();

    var data = "{\"userName\":\""+userName+"\",\"content\":\""+content+"\"}";
    return data;
}




// addUser($(".people"),"1400","img/1.jpg","张三","12:00 PM" ,"年后")



